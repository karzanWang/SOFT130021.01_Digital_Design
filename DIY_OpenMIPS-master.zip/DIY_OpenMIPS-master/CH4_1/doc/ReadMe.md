# 簡單算術實做

## 地雷

第一次照著書本實作模擬一次到位(灑花)，只是在實作`ex`階段花了點時間理解書本上的程式碼。

## 模擬結果

* 算術運算
    ![算術運算](SimulationResult_1.PNG)
    ![算術運算](SimulationResult_2.PNG)
    ![算術運算](SimulationResult_3.PNG)