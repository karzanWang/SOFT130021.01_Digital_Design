# 身為一個CPU，會邏輯跟位移運算也是很正常的

## 地雷

花最多力氣在debug的地方就是在找哪一條線路接錯了，導致上一個階段的pipeline沒有往後傳

## 模擬結果

* 邏輯運算
    ![邏輯運算](Test1/SimulationResult_1.PNG)
* 位移運算
    ![位移運算](Test2/SimulationResult_1.PNG)